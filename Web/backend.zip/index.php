<?php
	header ('Content-type: application/json');
	header('Access-Control-Allow-Origin: *');
	
	date_default_timezone_set('America/Los_Angeles');
	
	function convertDate($dateString)
	{
		if( !$dateString )
		{
			return "N/A";
		}
		$myDateTime = DateTime::createFromFormat('m/d/Y', $dateString);
		$newDateString = $myDateTime->format('d-M-Y');
		return $newDateString;
	}
	
	$street = urlencode( trim( $_GET["streetAddress"] ) );
	$city = urlencode( trim( $_GET["city"] ) );
	$state = urlencode( trim( $_GET["state"] ) );
	
	$message = "";
			
	$zwsid = "X1-ZWz1dy5by5fo5n_2f38x";
	$url = "http://www.zillow.com/webservice/GetDeepSearchResults.htm?zws-id=$zwsid&address=$street&citystatezip=$city+$state&rentzestimate=true";
	
	$obj = simplexml_load_file($url);
	$error = $obj->message->code;
	if( $error == 508 || $error == 502 || $error == 503 || $error == 507)
	{
		$message = "No exact match found--Verify that given address is correct.";
	}
	else if ( $error == 506 )
	{
		$message = "Address string too long. If address is valid, try using abbreviations.";
	}
	else if ( $error == 505 )
	{
		$message = "Request is timed out. Try after some time.";
	}
	else if ( $error == 3 )
	{
		$message = "The Zillow Web Service is currently not available. Please come back later and try again.";
	}
	$arr['message'] = $message;
	
	if( strlen($message) == 0 )
	{
	$results = $obj->response->results;
	$result = $obj->response->results->result;
	
	$headerLink = "<a href = '".$result->links->homedetails."'>".$result->address->street.", ".$result->address->city.", ".$result->address->state."-".$result->address->zipcode."</a>";
	$arr['headerLink'] = $headerLink;
	$arr['fblink'] = $result->links->homedetails;
	
	$propertyType = $result->useCode;
	$arr['propertyType'] = $propertyType;
	
	$lastSoldPrice = ((double)$result->lastSoldPrice);
	$lastSoldPrice = number_format( $lastSoldPrice, 2, ".", "," ); 
	$arr['lastSoldPrice'] = $lastSoldPrice;
	
	$arr['yearBuilt'] = $result->yearBuilt;
	$arr['valuationString'] = "Zestimate &reg; Property Estimate as of ".convertDate($result->zestimate->{'last-updated'});
	$arr['lastSoldDate'] = convertDate($result->lastSoldDate);
	$arr['lotSize'] = $result->lotSizeSqFt;
	
	$amount = ((double)$result->zestimate->amount);
	$amount = number_format( $amount, 2, ".", "," ); 
	$arr['propEst'] = $amount;
	
	$arr['finishedArea'] = $result->finishedSqFt;
	
	$changeAmt = ((double)$result->zestimate->valueChange);
	$arrow = "";
	$sign = "+";
	if( $changeAmt < 0 )
	{
		$sign = "-";
		$changeAmt *= -1;
		$arrow = "<img src = 'http://cs-server.usc.edu:45678/hw/hw6/down_r.gif' />";
	}
	else
	{
		$arrow = "<img src = 'http://cs-server.usc.edu:45678/hw/hw6/up_g.gif'/>";
	}
	$changeAmt = number_format( $changeAmt, 2, ".", "," );
	$arr['change1'] = $arrow."$".$changeAmt;
	$arr['c5'] = $sign;
	$arr['c6'] = $changeAmt;
	$arr['bathrooms'] = $result->bathrooms;
	
	$vr1 = ((double)$result->zestimate->valuationRange->low);
	$vr1 = number_format( $vr1, 2, ".", "," ); 
	$vr2 = ((double)$result->zestimate->valuationRange->high);
	$vr2 = number_format( $vr2, 2, ".", "," ); 
	$arr['range1'] = "$".$vr1." - $".$vr2;
	
	$arr['bedrooms'] = $result->bedrooms;
	$arr['valuationString1'] = "Rent Zestimate &reg; Valaution as of ".convertDate($result->rentzestimate->{'last-updated'});
	
	$amt = ((double) $result->rentzestimate->amount );
	$amt = number_format( $amt, 2, ".", "," ); 
	$arr['valueAmt'] = $amt;
	
	$arr['taxAssesmentYear'] = $result->taxAssessmentYear;
	
	$changeAmt = ((double)$result->rentzestimate->valueChange);
	if( $changeAmt < 0 )
	{
		$changeAmt *= -1;
		$arrow = "<img src = 'http://cs-server.usc.edu:45678/hw/hw6/down_r.gif' />";
	}
	else
	{
		$arrow = "<img src = 'http://cs-server.usc.edu:45678/hw/hw6/up_g.gif'/>";
	}
	$changeAmt = number_format( $changeAmt, 2, ".", "," );
	$arr['change2'] = $arrow."$".$changeAmt;
	
	$amt = ((double) $result->taxAssessment );
	$amt = number_format( $amt, 2, ".", "," );
	$arr['taxAssessment'] = $amt;
	
	$vr1 = ((double)$result->rentzestimate->valuationRange->low);
	$vr1 = number_format( $vr1, 2, ".", "," ); 
	$vr2 = ((double)$result->rentzestimate->valuationRange->high);
	$vr2 = number_format( $vr2, 2, ".", "," ); 
	$arr['range2'] = "$".$vr1." - $".$vr2;
	//Chart
	$zpid = $result->{zpid};
	$c1 = "http://www.zillow.com/webservice/GetChart.htm?zws-id=$zwsid&zpid=$zpid&width=600&height=300&chartDuration=1year&unit-type=percent";
	$obj = simplexml_load_file($c1);
	$arr['c1'] = $obj->response->url;
	
	$c2 = "http://www.zillow.com/webservice/GetChart.htm?zws-id=$zwsid&zpid=$zpid&width=600&height=300&chartDuration=5years&unit-type=percent";
	$obj = simplexml_load_file($c2);
	$arr['c2'] = $obj->response->url;
	
	$c3 = "http://www.zillow.com/webservice/GetChart.htm?zws-id=$zwsid&zpid=$zpid&width=600&height=300&chartDuration=10years&unit-type=percent";
	$obj = simplexml_load_file($c3);
	$arr['c3'] = $obj->response->url;
	
	$arr['c1l'] = "Historical Zestimates for past 1 year";
	$arr['c2l'] = "Historical Zestimates for past 5 years";
	$arr['c3l'] = "Historical Zestimates for past 10 years";
	$arr['c4'] = $result->address->street.", ".$result->address->city.", ".$result->address->state."-".$result->address->zipcode;
	}
	
	echo $_GET['callback'] . '('. json_encode($arr) . ');';
?>
